__version__ = "0.1.0"
__author__ = 'Matthew Plumlee, Özge Sürer, Stefan M. Wild'
__credits__ = 'Northwestern University, Argonne National Laboratory'
