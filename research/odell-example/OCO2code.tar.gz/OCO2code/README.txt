####################################################################
This directory contains codes to implment methods in the manuscript titled "Computer Model Emulation with High-Dimensional Functional Output in Large-Scale Observing System Uncertainty Experiments".

Copyright (c) [2020] by the authors.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
####################################################################


###############################################################################
############## General description
# This routine shows the entire pipelines to implement the NNGP-based emulator
# in combination with the active subspace approach for dimension reduction. 
# The details of the methods can be found in the paper titled "Computer Model
# Emulation with High-Dimensional Functional Output in Large-Scale Observing
# System Uncertainty Experiments" by the authors.
#
###############################################################################
#
############ Instructions for overall picture 
#The entire codes have three parts.
# ####### Part1: 
# (1) In the first part, R codes are used to implement functional principal
# component analysis (FPCA) so that the functional output from OCO-2 forward 
# model can be represented as a linear combination of basis functions and 
# corresponding FPC scores. 
######## Part 2:
# (2) In the second part, R codes are used to find the active subspace from 
# the space formed by the state vectors. The key quantity here is the 
# projection matrix that projects a high-dimensional space into a low-dimensional
# space.
####### Part 3:
# (3) In the third part, MATLAB codes are used to train the NNGP emulator based
# on a set of training data, in which the active variables and viewing geometry
# are treated as input variables, and FPC scores are treated as output. 
###############################################################################


###############################################################################
###### Note on the data
# Data can be downloaded at the NASA Goddard Earth Science Data and Information Services Center (GES DISC https://disc.gsfc.nasa.gov/datasets?page=1\&keywords=OCO-2). 
# This dataset from the full-physics forward model is around 9GB. Please use it for caution. 
# Instead, we only provide a subset of the original data, and save them as formats 
# that can be read into R and MATLAB easily. The dataset for the reduced order model
# is available upon request subject to NASA JPL data sharing protocol. 
###############################################################################

###############################################################################
##### Note on the code
# 1. We only provide the code to perform FPCA, active subspace, and NNGP emulation.  
# Detailed instrations for these three components can be found in the file main.R.
# 2. As performing active subspace requires downloading the full dataset that is too 
# large to upload, we only provide relevant code to implement active subspace, and 
# the resulting active variables. 
# 3. The NNGP emulator is provided as a general form that implements the independent emulator
# for all the bands, and separable emulator for the WCO2 and SCO2. 
# 4. For O2 band, we peform independent emulation with three different files: 
# (1) O21_AS_nugget_IndEmulation.m. This file contains the emulation code for the 
# first FPC score for the O2 band.
# (2) O22_AS_nugget_IndEmulation.m. This file contains the emulation code for the 
# second FPC score for the O2 band.   
# (3) O23_AS_nugget_IndEmulation.m. This file contains the emulation code for the 
# third FPC score for the O2 band.
# 5. For the WCO2 and SCO2 bands, we can use independent emulator and separable emulator.
# For independent emulator, the corresponding files are WCO2_AS_nugget_IndEmulation.m
# and SCO2_AS_nugget_IndEmulation.m; For Separable emulator, the corresponding files 
# are CO2_AS_nugget_SepEmulation.m

###############################################################################
##### What you can expect from the code?
# The results for NNGP emulators in Table 2 and Table 3 can be reproduced with the code along with Figures 3 to 6. The results based on the Reduced Order Model (ROM) are excluded since
# the ROM data are only available upon request. 

